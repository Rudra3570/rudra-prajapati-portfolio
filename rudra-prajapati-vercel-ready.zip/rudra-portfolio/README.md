# Rudra Prajapati — Data Analyst Portfolio

Next.js + React + TypeScript + Tailwind CSS portfolio, prepared for Vercel deployment.

## Deploy to Vercel

1. Upload this project to a GitHub repository.
2. Open https://vercel.com/new
3. Import the GitHub repository.
4. Vercel should detect **Next.js** automatically.
5. Click **Deploy**. No environment variables are required for the current frontend-only version.

## Local development

```bash
npm install
npm run dev
```

Open http://localhost:3000.
